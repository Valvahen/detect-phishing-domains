document.addEventListener('DOMContentLoaded', function () {
    const sourceSelect = document.getElementById('source-select');
    const nixiFileInput = document.getElementById('nixi-file-input');
    const listDomainsFileInput = document.getElementById('list-domains-file-input');
    const dateInputDiv = document.getElementById('date-input-div');
    const featureSelection = document.getElementById('feature-selection');

    function toggleFields() {
        const selectedSource = sourceSelect.value;

        console.log('Selected source:', selectedSource); // Debug log

        // Reset visibility
        nixiFileInput.style.display = 'none';
        listDomainsFileInput.style.display = 'none';
        dateInputDiv.style.display = 'none';

        if (selectedSource === 'nixi') {
            nixiFileInput.style.display = 'block'; // Show NIXI file input
            dateInputDiv.style.display = 'block'; // Show date input for NIXI
        } else if (selectedSource === 'list-domains') {
            listDomainsFileInput.style.display = 'block'; // Show file input for list-domains
        } else if (selectedSource == 'logo') {
            listDomainsFileInput.style.display = 'block';
            featureSelection.style.display = 'none';
        }
    }

    // Initial check
    toggleFields();

    // Add event listener to dropdown menu
    sourceSelect.addEventListener('change', toggleFields);

    document.getElementById('upload-form').addEventListener('submit', function (e) {
        e.preventDefault();

        const selectedSource = sourceSelect.value;
        const nixiFile = document.getElementById('nixi-file').files[0];
        const listDomainsFile = document.getElementById('list-domains-file').files[0];
        const dateInput = document.getElementById('date-input');

        const formData = new FormData();
        
        if (selectedSource === 'nixi' && nixiFile) {
            formData.append('file', nixiFile);
            formData.append('date', dateInput.value);
        } else if (selectedSource === 'list-domains' && listDomainsFile) {
            formData.append('file', listDomainsFile);
            formData.append('date', ''); // No date needed for list-domains
        } else if (selectedSource === 'whois') {
            formData.append('date', ''); // No file needed for Whois
        } else if(selectedSource == 'logo') {
            formData.append('file', listDomainsFile);
            formData.append('date', ''); // No date needed for logo
        }  else {
            alert('Please provide the necessary file and date input.');
            return;
        }

        // Collect selected features
        const featureCheckboxes = document.querySelectorAll('input[name="features"]:checked');
        const selectedFeatures = [];
        featureCheckboxes.forEach(checkbox => {
            selectedFeatures.push(checkbox.value);
        });
        formData.append('features', JSON.stringify(selectedFeatures));
        
        // Collect selected source value
        formData.append('source', selectedSource);

        // Show loading bar
        const loading = document.getElementById('loading');
        loading.style.display = 'block';

        // Hide previous results and errors
        const resultsContainer = document.getElementById('results');
        const errorMessage = document.getElementById('error-message');
        const timeTaken = document.getElementById('time-taken');
        resultsContainer.innerHTML = '';
        errorMessage.textContent = '';
        timeTaken.textContent = '';

        const startTime = Date.now(); // Start time

        fetch('http://127.0.0.1:5000/detect-phishing', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Hide loading indicator
            loading.style.display = 'none';

            // Check if data contains a link to download CSV
            if (data.csv_download_link) {
                const downloadLink = document.createElement('a');
                downloadLink.href = data.csv_download_link;
                downloadLink.textContent = 'Download CSV';
                downloadLink.download = data.filename;

                resultsContainer.appendChild(downloadLink);
            } else {
                console.error('Error: No CSV download link found in response.');
                errorMessage.textContent = 'Error: No CSV download link found.';
            }

            const endTime = Date.now();
            const timeElapsed = ((endTime - startTime) / 1000).toFixed(2);
            timeTaken.textContent = `Time taken: ${timeElapsed} seconds`;
        })
        .catch(error => {
            console.error('Error:', error);
            errorMessage.textContent = `Error: ${error.message}`;
            loading.style.display = 'none'; // Hide loading bar
        });
    });
});
