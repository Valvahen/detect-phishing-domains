from flask import jsonify, request, Flask, send_file
from flask_cors import CORS
import pandas as pd
import json
import time
from .modules.process_child_domain_in_batches import process_child_domains_in_batches
from .modules.determine_status import determine_status
from .modules.get_whois_dataset import get_whois_dataset
import os
from .config import whitelist, model, screenshot_dir, driver, predefined_labels, whois_extracted_dateset_directory_path
from .modules.filter_nixi_file import filter_nixi_file
import cv2
from .modules.take_screenshots_from_csv import take_screenshots_from_csv
from .modules.get_next_available_filename import get_next_available_filename
import shutil

# Flask setup
app = Flask(__name__)
CORS(app)

@app.route('/', methods=['POST'])
def hello_world():
    return "Hello, World!"

@app.route('/detect-phishing', methods=['POST'])
def detect_phishing():
    selected_features = json.loads(request.form['features'])
    source = request.form['source']
    parent_data = pd.read_csv(whitelist)
    parent_domains = parent_data['domain'].values

    if source == 'whois':
        print("Processing with whois")
        base_filename = "my_app\\data\\whois_results\\result_whois.csv"

        # Fetch the WHOIS dataset file path
        file_path = get_whois_dataset()
        print(f"WHOIS dataset path: {file_path}")
        
        # Ensure that the file path is correctly read
        if not os.path.exists(file_path):
            return jsonify({"error": "WHOIS dataset file not found"}), 500
        
        # Read the content of the WHOIS dataset file
        with open(file_path, 'r') as file:
            child_domains = file.read().splitlines()
        
        
    # Add your NIXI specific processing here
    elif source == 'nixi':
        
        print("Processing with nixi")
        # Add your WHOIS specific processing here

        file = request.files['file']
        child_domains = filter_nixi_file(file)
        # child_domains = file.read().decode('utf-8').splitlines()
        # Check if 'date' field is provided and handle appropriately
        if 'date' in request.form and request.form['date']:
            base_filename = f'my_app/data/nixi_results/{request.form["date"]}.csv'
        else:
            base_filename = f'my_app/data/nixi_results/result_nixi_(date_not_found).csv'

    elif source == 'list-domains':
        print("Processing with list of domains")
        file = request.files['file']
        child_domains = file.read().splitlines()
        base_filename = f'my_app/data/list_of_domains_results/result_list_domains.csv'

    if source == 'whois' or source == 'nixi' or source == 'list-domains':
        start_processing_time = time.time()
        csv_filename = process_child_domains_in_batches(child_domains, parent_domains, selected_features, base_filename)
        end_processing_time = time.time()
        processing_time = end_processing_time - start_processing_time
        if source == 'whois':
            if os.path.exists(whois_extracted_dateset_directory_path):
                # Iterate over all files in the directory
                for filename in os.listdir(whois_extracted_dateset_directory_path):
                    file_path = os.path.join(whois_extracted_dateset_directory_path, filename)
                    try:
                        # Check if it is a file and delete it
                        if os.path.isfile(file_path) or os.path.islink(file_path):
                            os.unlink(file_path)
                        # Check if it is a directory and delete it
                        elif os.path.isdir(file_path):
                            shutil.rmtree(file_path)
                    except Exception as e:
                        print(f'Failed to delete {file_path}. Reason: {e}')
            else:
                print(f'The directory {whois_extracted_dateset_directory_path} does not exist.')

        print(f"Time taken for processing: {processing_time} seconds")

        # Read the original CSV file
        df = pd.read_csv(csv_filename)

        # Check which columns exist in the original CSV
        existing_columns = df.columns.tolist()

        # Apply determine_status and append the status to the original DataFrame
        df['status'] = df.apply(determine_status, axis=1, existing_columns=existing_columns)

        # Save the DataFrame with the status column appended to the original CSV file
        df.to_csv(csv_filename, index=False)

        print("CSV file with status column saved successfully.")

    if source == 'logo':
        if 'file' not in request.files:
         return jsonify({"error": "No file part"}), 400
    
        file = request.files['file']
        if file.filename == '':
            return jsonify({"error": "No selected file"}), 400
        
        if file:
            file_path = os.path.join(screenshot_dir, file.filename)
            file.save(file_path)

            # Take screenshots of domains from CSV
            screenshots = take_screenshots_from_csv(file_path)
            driver.quit()

            # List to store detection results
            results = []

            # Detect logos in screenshots
            for url, screenshot_path in screenshots:
                if os.path.exists(screenshot_path):
                    # Example evaluation on a validation set
                    results_yolo = model(screenshot_path)

                    # Assuming results is an instance of ultralytics.engine.results.Results
                    if isinstance(results_yolo, list) and len(results_yolo) > 0:
                        detected_objects = results_yolo[0].names
                        detected_labels = set()  # Store detected labels

                        # Load the image
                        img = cv2.imread(screenshot_path)

                        # Draw bounding boxes and labels on the image
                        for box in results_yolo[0].boxes:
                            # Convert tensor to list
                            box_coordinates = box.xyxy[0].tolist()
                            x1, y1, x2, y2 = map(int, box_coordinates)
                            label = detected_objects[box.cls.item()]

                            # Check if the label is in the predefined objects
                            if label in predefined_labels:
                                detected_labels.add(label)

                                # Draw the bounding box
                                cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)

                                # Put the label text above the bounding box
                                cv2.putText(img, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

                        # Save the image with bounding boxes (if needed)
                        cv2.imwrite(f"{screenshot_path[:-4]}_with_boxes.png", img)

                        # Add detected labels to results
                        for label in detected_labels:
                            results.append({'URL': url, 'Detected Logo': label})
                    else:
                        print(f"Error: Unexpected results format for {screenshot_path}.")
                else:
                    print(f"File not found: {screenshot_path}")

            # Save results to CSV
            df = pd.DataFrame(results)
            base_filename = "my_app\\data\\logo_results\\detected_logos.csv"
            logo_filename = get_next_available_filename(base_filename)
            df.to_csv(logo_filename, index=False)
            csv_filename = logo_filename

    # Generate link to download CSV
    csv_download_link = f'http://127.0.0.1:5000/download/{csv_filename}'

    return jsonify({"csv_download_link": csv_download_link}), 200
        
    
@app.route('/download/<filename>', methods=['GET'])
def download_csv(filename):
    csv_path = os.path.join(app.root_path, filename)
    return send_file(csv_path, as_attachment=True)
  
if __name__ == "__main__":
    import sys
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 5000
    app.run(host='0.0.0.0', port=port)
