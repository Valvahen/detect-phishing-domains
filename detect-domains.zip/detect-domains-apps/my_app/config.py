import nltk
from queue import Queue
import requests
import ssl
from ultralytics import YOLO
import os
from selenium import webdriver

# Suppress SSL warnings
requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)
ssl._create_default_https_context = ssl._create_unverified_context

# Disable SSL certificate verification
session = requests.Session()
session.verify = False

# Download NLTK tokenizer data
nltk.download('stopwords')
nltk.download('punkt')

# Define dictionaries to store cached data
content_cache = {}
title_cache = {}

# Queue to manage URLs for Selenium content extraction
url_queue = Queue()

whitelist = "my_app\\data\\whitelist.csv"
malicious_ips_file_path = 'my_app\\data\\known_malicious_IPs.csv'
blacklist = "my_app\\data\\blacklist.csv"
csv_filename = "my_app\\data\\downloaded_dates.csv"
whois_extracted_dateset_directory_path = "my_app\\data\\datasets\\extracted"
whois_combined_dateset_directory_path = "my_app\\data\\datasets\\combined"
whois_zips_dateset_directory_path = "my_app\\data\\datasets\\zips"

max_workers = 100

model = YOLO('my_app\\data\\best.pt')

screenshot_dir = 'my_app\\data\\blacklist_screenshots'
os.makedirs(screenshot_dir, exist_ok=True)

# Set up Chrome options for headless mode
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_argument('--headless')
chromeOptions.add_argument('--disable-gpu')
chromeOptions.add_argument('--ignore-certificate-errors')
chromeOptions.add_argument("--log-level=1")

# Set up the Selenium WebDriver
driver = webdriver.Chrome(options=chromeOptions)

# Predefined list of objects
predefined_objects = {
    0: 'aadhar', 1: 'adani', 2: 'airtel', 3: 'assam_sldc', 4: 'axis', 5: 'bbmb',
    6: 'bescom', 7: 'bob', 8: 'boi', 9: 'bse', 10: 'bses', 11: 'bsnl', 12: 'canara',
    13: 'cdsl', 14: 'census_india', 15: 'central_bank_of_india', 16: 'cesc', 17: 'cptcl',
    18: 'csrorgi', 19: 'dgshipping', 20: 'dvc', 21: 'gail', 22: 'grid', 23: 'gst',
    24: 'hdfc', 25: 'hpsldc', 26: 'iccl', 27: 'icici', 28: 'idbi', 29: 'indian_bank',
    30: 'iocl', 31: 'isro', 32: 'jio', 33: 'kerala_sldc', 34: 'kotak', 35: 'kptcl',
    36: 'lic', 37: 'mccil', 38: 'mcx', 39: 'megsldc', 40: 'mpcz', 41: 'mpez', 42: 'mpsldc',
    43: 'mpwz', 44: 'mse', 45: 'mtnl', 46: 'nic', 47: 'npci', 48: 'npcl', 49: 'npl',
    50: 'nsdl', 51: 'nse', 52: 'paytm', 53: 'pnb', 54: 'power', 55: 'pstcl', 56: 'rajasthan_sldc',
    57: 'rbi', 58: 'sbi', 59: 'tamil_nadu_sldc', 60: 'tata_power', 61: 'tata_power_ddl',
    62: 'telangana_sldc', 63: 'uk_sldc', 64: 'union_bank', 65: 'videocon', 66: 'vodafone',
    67: 'wbsedcl', 68: 'yes_bank'
}

# Reverse the predefined_objects dictionary for easy lookup
predefined_labels = {v: k for k, v in predefined_objects.items()}
