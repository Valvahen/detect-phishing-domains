import pandas as pd
from .ensure_scheme import ensure_scheme
import requests
from ..config import driver
import os
from ..config import screenshot_dir

# Function to take screenshots
def take_screenshots_from_csv(csv_file):
    screenshots = []
    df = pd.read_csv(csv_file)
    domains = df['domain'].tolist()
    for domain in domains:
        try:
            url = ensure_scheme(domain)
            response = requests.options(url)
            if response.ok or response.status_code == 403:
                driver.get(url)
                driver.set_window_size(1920, 1080)  # Set window size for full page capture
                screenshot_path = os.path.join(screenshot_dir, f"{domain.replace('.', '_')}.png")
                driver.save_screenshot(screenshot_path)
                screenshots.append((url, screenshot_path))
                print(f"Screenshot saved to {screenshot_path}")
            else:
                print(f"{domain} is accessible but something is not right. Response code: {response.status_code}")
        except (requests.exceptions.HTTPError, requests.exceptions.ConnectionError) as e:
            print(f"Unable to establish connection: {e}.")
        except Exception as e:
            print(f"Error taking screenshot of {domain}: {e}")
            continue
    return screenshots